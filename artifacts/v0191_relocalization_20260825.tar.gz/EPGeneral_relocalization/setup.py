from setuptools import find_packages, setup

setup(
    name="epgeneral_relocalization",
    version="0.2.1",
    package_dir={"": "src"},
    packages=find_packages("src"),
)
