# 更新记录

## v0.3.0 - 2026-09-04

- 新增 `ground_air_agv` backend 和工作区级 launch 覆盖环境。
- Ground-Air 以固定 1 秒周期上报最新 `map <- odom`，首个有效样本立即成功；连续缺失达到超时后失败。
- 连续结果首次立即持久化，之后最多每 30 秒及正常退出时刷新，Scout/Wheeltec 稳定窗口保持不变。

## v0.2.3 - 2026-09-02

- 将运行配置迁移至 `epgeneral_device_config`，重定位协议与状态机保持不变。
