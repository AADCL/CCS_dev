# epgeneral_relocalization

当前版本 v0.2.0。每次协商（包括 Go2 的 `UNSUPPORTED_BACKEND`）都会原子写入 `~/.ros/ccs_edge_dev/state/relocalization.json`，供 UDP 遥测按当前 map ID 检查 PGM 文件。

ROS1 常驻重定位协调包。它监听 `ccs-relocalization-v1` UDP 控制消息，从已配置的地面站 HTTP 地址续传地图 ZIP，严格校验 manifest、大小和 SHA-256 后原子安装，再按 profile 顺序启动 Scout FAST-LIO、坐标适配、全局 PCD 重定位和 map_server。

Scout profile 默认使用 `~/livox_fastlio/maps/ccs_download/<map_id>/`。Go2 profile 当前必须设置 `enabled: false`，节点只返回 `UNSUPPORTED_BACKEND`，不宣称已有全局重定位能力。

成功判据为连续稳定的 `map <- odom` TF。初始位姿发布至 `/initialpose`，结果和失败原因返回地面站；耐久日志位于 `~/.ros/ccs_edge_dev/log/relocalization.log`。
